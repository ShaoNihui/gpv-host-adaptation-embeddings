#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Make a 2-panel UMAP figure:
A) UMAP colored by host (from umap_host.tsv)
B) UMAP with mismatches highlighted and annotated (from umap_mismatch.tsv)

Inputs (TSV columns expected):
- umap_host.tsv: accession, label, umap_x, umap_y
- umap_mismatch.tsv: accession, label, umap_x, umap_y, is_mismatch (bool-like)

Usage example:
python src/make_combined_figure_umap.py \
  --host_tsv results/esm/umap_host.tsv \
  --mismatch_tsv results/esm/umap_mismatch.tsv \
  --out_dir results/esm \
  --width 12 --height 5.2 --dpi 600 \
  --point_size 20 --alpha 0.9 \
  --annotate_topk 8 --annot_fontsize 5.0 \
  --arrow_lw 0.6 --shrinkA 12 --shrinkB 12 \
  --dx 0.35 --dy 0.35 \
  --panel_labels A B
"""

import os
import argparse
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
from adjustText import adjust_text


PALETTE = {
    "Unknown": "#8a9aa9",      # grey-blue
    "Goose": "#6aa4d8",         # blue
    "Muscovy duck": "#e8a257",  # orange
    "Swan": "#e3c6e6",          # light purple
    "Duck": "#6abf7a",          # green
}
MISMATCH_EDGE = "#8b2f2f"       # dark red
MISMATCH_FACE = "none"

def legend_handles_safe(leg):
    """Return legend handles in a way that works for Matplotlib <3.9 and >=3.9."""
    return getattr(leg, "legendHandles", getattr(leg, "legend_handles", []))

def read_tsv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path, sep="\t")
    need = {"accession", "label", "umap_x", "umap_y"}
    if not need.issubset(df.columns):
        missing = need - set(df.columns)
        raise ValueError(f"{path} is missing columns: {missing}")
    return df

def _scatter_panel(ax, df, point_size=20, alpha=0.9, legend=True):
    """Scatter points by host label with consistent palette."""
    for host, sub in df.groupby("label", sort=False):
        color = PALETTE.get(host, "#999999")
        ax.scatter(
            sub["umap_x"], sub["umap_y"],
            s=point_size, c=color, alpha=alpha,
            edgecolor="none", linewidths=0.0, label=host
        )
    ax.set_xlabel("UMAP-1")
    ax.set_ylabel("UMAP-2")
    ax.grid(False)

    if legend:
        # Build a categorical legend using our palette order
        order = [k for k in ["Unknown","Goose","Muscovy duck","Swan","Duck"] if k in df["label"].unique()]
        handles = [Line2D([0],[0], marker='o', linestyle='',
                          color='none', markerfacecolor=PALETTE[h], markersize=6,
                          label=h) for h in order]
        leg = ax.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.5,-0.18),
                        ncol=len(order), frameon=False, handletextpad=0.6, columnspacing=1.2)
        # Resize legend dots (compat across MPL versions)
        for lh in legend_handles_safe(leg):
            if hasattr(lh, "set_markersize"):
                lh.set_markersize(6)

def _mismatch_panel(ax, df_mis, point_size=20, alpha=0.9,
                    annotate_topk=8, annot_fontsize=5.5,
                    arrow_lw=0.7, shrinkA=10, shrinkB=10,
                    dx=0.3, dy=0.3):
    """Plot all points with palette, highlight mismatches and annotate top-k."""
    # Base scatter by host color
    for host, sub in df_mis.groupby("label", sort=False):
        color = PALETTE.get(host, "#999999")
        ax.scatter(
            sub["umap_x"], sub["umap_y"],
            s=point_size, c=color, alpha=alpha,
            edgecolor="none", linewidths=0.0, label=host
        )

    # Highlight mismatches
    if "is_mismatch" not in df_mis.columns:
        raise ValueError("mismatch TSV must have column 'is_mismatch' (True/False).")
    mis = df_mis[df_mis["is_mismatch"].astype(str).str.lower().isin(["true","1","yes"])].copy()

    ax.scatter(
        mis["umap_x"], mis["umap_y"],
        s=point_size*1.1, facecolor=MISMATCH_FACE, edgecolor=MISMATCH_EDGE,
        linewidths=1.0, label="Mismatch", zorder=4
    )

    # annotate (pick top-k by “crowdedness” for readability)
    texts = []
    if annotate_topk and len(mis) > 0:
        # rank by local density (approx): negative distance to nearest neighbor
        coords = mis[["umap_x","umap_y"]].to_numpy()
        nn_dist = []
        for i in range(len(coords)):
            d = np.sqrt(((coords - coords[i])**2).sum(axis=1))
            d[i] = np.inf
            nn_dist.append(d.min())
        mis = mis.iloc[np.argsort(nn_dist)]  # small distance first (crowded)
        mis = mis.head(int(annotate_topk))

        for _, r in mis.iterrows():
            txt = ax.text(
                r["umap_x"]+dx, r["umap_y"]+dy,
                str(r["accession"]),
                fontsize=annot_fontsize, color=MISMATCH_EDGE,
                ha="center", va="center", zorder=5
            )
            texts.append(txt)
            # draw a faint line
            ax.annotate(
                "", xy=(r["umap_x"], r["umap_y"]),
                xytext=(r["umap_x"]+dx, r["umap_y"]+dy),
                arrowprops=dict(arrowstyle="-", color=MISMATCH_EDGE,
                                lw=arrow_lw, shrinkA=shrinkA, shrinkB=shrinkB, alpha=0.8),
                zorder=4
            )
        # repel labels
        adjust_text(
            texts,
            only_move={'points':'y','texts':'xy'},
            autoalign='xy',
            expand_points=(1.2,1.2),
            expand_text=(1.1,1.2),
            arrowprops=dict(arrowstyle="-", color=MISMATCH_EDGE, lw=0.0),
            ax=ax
        )

    # Build legend with mismatch item appended
    order = [k for k in ["Unknown","Goose","Muscovy duck","Swan","Duck"] if k in df_mis["label"].unique()]
    handles = [Line2D([0],[0], marker='o', linestyle='',
                      color='none', markerfacecolor=PALETTE[h], markersize=6,
                      label=h) for h in order]
    handles.append(Line2D([0],[0], marker='o', linestyle='',
                          markerfacecolor=MISMATCH_FACE, markeredgecolor=MISMATCH_EDGE,
                          markeredgewidth=1.0, markersize=6, label="Mismatch"))
    leg2 = ax.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.5,-0.18),
                     ncol=len(handles), frameon=False, handletextpad=0.6, columnspacing=1.2)
    for lh in legend_handles_safe(leg2):
        if hasattr(lh, "set_markersize"):
            lh.set_markersize(6)

    ax.set_xlabel("UMAP-1")
    ax.set_ylabel("UMAP-2")
    ax.grid(False)

def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host_tsv", required=True)
    ap.add_argument("--mismatch_tsv", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--width", type=float, default=12.0)
    ap.add_argument("--height", type=float, default=5.2)
    ap.add_argument("--dpi", type=int, default=600)
    ap.add_argument("--point_size", type=float, default=20.0)
    ap.add_argument("--alpha", type=float, default=0.9)
    ap.add_argument("--annotate_topk", type=int, default=8)
    ap.add_argument("--annot_fontsize", type=float, default=5.0)
    ap.add_argument("--arrow_lw", type=float, default=0.6)
    ap.add_argument("--shrinkA", type=float, default=12)
    ap.add_argument("--shrinkB", type=float, default=12)
    ap.add_argument("--dx", type=float, default=0.35)
    ap.add_argument("--dy", type=float, default=0.35)
    ap.add_argument("--panel_labels", nargs=2, default=["A","B"])
    return ap.parse_args()

def main():
    args = parse_args()
    os.makedirs(args.out_dir, exist_ok=True)

    host = read_tsv(args.host_tsv)
    mis  = read_tsv(args.mismatch_tsv)

    fig, (axA, axB) = plt.subplots(1, 2, figsize=(args.width, args.height), dpi=args.dpi)

    # Panel A
    _scatter_panel(axA, host, point_size=args.point_size, alpha=args.alpha, legend=True)
    axA.text(0.01, 0.98, args.panel_labels[0], transform=axA.transAxes,
             fontsize=16, fontweight="bold", va="top", ha="left")

    # Panel B
    _mismatch_panel(
        axB, mis,
        point_size=args.point_size, alpha=args.alpha,
        annotate_topk=args.annotate_topk, annot_fontsize=args.annot_fontsize,
        arrow_lw=args.arrow_lw, shrinkA=args.shrinkA, shrinkB=args.shrinkB,
        dx=args.dx, dy=args.dy
    )
    axB.text(0.01, 0.98, args.panel_labels[1], transform=axB.transAxes,
             fontsize=16, fontweight="bold", va="top", ha="left")

    fig.tight_layout(w_pad=3.0)

    out_png = os.path.join(args.out_dir, "umap_combined.png")
    out_pdf = os.path.join(args.out_dir, "umap_combined.pdf")
    out_svg = os.path.join(args.out_dir, "umap_combined.svg")
    fig.savefig(out_png, bbox_inches="tight")
    fig.savefig(out_pdf, bbox_inches="tight")
    fig.savefig(out_svg, bbox_inches="tight")
    print(f"[OK] Combined figure -> {out_png} / .pdf / .svg")

if __name__ == "__main__":
    main()