export QT_XCB_GL_INTEGRATION=none
export QT_QPA_PLATFORM=offscreen
export MPLBACKEND=Agg

cat > work/render_fig5D_only_fix.pml <<'PML'
reinitialize
python
import os
from pymol import cmd

BASE="/data/users/nshao/GPV_AI_Project/Fig5_Structure_Electrostatics"
WRK=os.path.join(BASE,"work")
OUT=os.path.join(BASE,"outputs")
os.makedirs(OUT, exist_ok=True)

def render_one(tag, pdb, dx, outpng, view=None):
    cmd.reinitialize()
    cmd.load(os.path.join(WRK, pdb), tag)
    cmd.hide("everything", tag)
    cmd.show("surface", tag)
    cmd.set("surface_quality", 1, tag)
    cmd.set("specular", 0)
    cmd.load(os.path.join(WRK, dx), f"map_{tag}")
    # -5→蓝, 0→白, +5→红
    cmd.ramp_new(f"ramp_{tag}", f"map_{tag}", [-5, 0, 5])
    cmd.set("surface_color", f"ramp_{tag}", tag)
    if view is None:
        cmd.orient(tag); cmd.turn("y", 25); cmd.turn("x", -10)
        view = cmd.get_view()
    else:
        cmd.set_view(view)
    cmd.png(os.path.join(OUT, outpng), width=2200, height=1700, dpi=600, ray=1)
    return view

# 先用 GPV 生成基准视角，再复用到其余两张
view_ref = render_one("GPV",        "GPV_model.pdb",        "GPV_pot.dx",        "Fig5D_electrostatics_GPV.png",        None)
render_one("Transition", "Transition_model.pdb", "Transition_pot.dx", "Fig5D_electrostatics_Transition.png", view_ref)
render_one("MDPV",       "MDPV_model.pdb",       "MDPV_pot.dx",       "Fig5D_electrostatics_MDPV.png",       view_ref)
python end
PML

/data/users/nshao/conda_envs/pymol_env/bin/pymol -cq work/render_fig5D_only_fix.pml > work/step04_pymol_render_only_fix.log 2>&1

# 查看是否生成三张图；若没有，打印渲染日志末尾
ls -lh outputs/Fig5D_electrostatics_*.png || tail -n 120 work/step04_pymol_render_only_fix.log