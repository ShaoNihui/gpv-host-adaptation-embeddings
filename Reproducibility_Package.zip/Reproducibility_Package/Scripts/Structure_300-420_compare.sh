#!/usr/bin/env bash
#SBATCH --job-name=fig4F_vp1_loop_inset_clean
#SBATCH --partition=pibu_el8
#SBATCH --cpus-per-task=4
#SBATCH --mem=8G
#SBATCH --time=02:00:00
#SBATCH --mail-user=nihui.shao@students.unibe.ch
#SBATCH --mail-type=BEGIN,END,FAIL
#SBATCH --output=/data/users/%u/GPV_AI_Project/Fig5_Structure_Electrostatics/logs/fig4F_clean_%j.out
#SBATCH --error=/data/users/%u/GPV_AI_Project/Fig5_Structure_Electrostatics/logs/fig4F_clean_%j.err

PYMOL="/data/users/nshao/conda_envs/pymol_env/bin/pymol"
PROJ="/data/users/nshao/GPV_AI_Project/Fig5_Structure_Electrostatics"
WORK="$PROJ/work"
OUT="$PROJ/outputs"
LOG="$PROJ/logs"

mkdir -p "$WORK" "$OUT" "$LOG"

cat > "$WORK/make_fig4F_inset_clean.pml" <<'PML'
reinitialize
bg_color white
set antialias, 2
set ray_shadows, off
set depth_cue, 0
set two_sided_lighting, on
set surface_quality, 1
set cartoon_transparency, 0.15

load /data/users/nshao/GPV_AI_Project/Fig5_Structure_Electrostatics/work/GPV_model.pdb, GPV
load /data/users/nshao/GPV_AI_Project/Fig5_Structure_Electrostatics/work/MDPV_model.pdb, MDPV

hide everything
show cartoon, GPV or MDPV

set_color gpv_col,       [0.00, 0.45, 0.70]
set_color mdpv_col,      [0.90, 0.60, 0.00]
set_color gpv_loop_col,  [0.00, 0.62, 0.45]
set_color mdpv_loop_col, [0.84, 0.15, 0.16]

color gpv_col, GPV
color mdpv_col, MDPV
align MDPV, GPV

select GPV_loop,  GPV  and resi 300-420
select MDPV_loop, MDPV and resi 300-420
select loop_300_420, GPV_loop or MDPV_loop

set cartoon_transparency, 0.5, GPV or MDPV
set cartoon_transparency, 0.0, GPV_loop or MDPV_loop
color gpv_loop_col,  GPV_loop
color mdpv_loop_col, MDPV_loop

show sticks, (name CA+N+C+O+CB) and loop_300_420
set stick_radius, 0.25, loop_300_420

select mut_sites, (resi 325+389+405) and (GPV or MDPV)
show sticks, mut_sites
set stick_radius, 0.40, mut_sites

orient loop_300_420
zoom loop_300_420, 6

ray 1800,1400
png /data/users/nshao/GPV_AI_Project/Fig5_Structure_Electrostatics/outputs/Fig4F_VP1_loop300_420_inset_clean.png, dpi=600
PML

"$PYMOL" -cq "$WORK/make_fig4F_inset_clean.pml"