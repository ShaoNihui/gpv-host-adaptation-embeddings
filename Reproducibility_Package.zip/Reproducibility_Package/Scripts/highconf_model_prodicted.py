#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl


def get_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tsv", required=True, help="results/esm/umap_highconf.tsv")
    ap.add_argument("--out_prefix", required=True, help="output prefix (without extension)")
    ap.add_argument("--dpi", type=int, default=600)
    ap.add_argument("--width", type=float, default=6.8)
    ap.add_argument("--height", type=float, default=5.5)
    ap.add_argument("--fontsize", type=float, default=9.5)
    ap.add_argument("--point_size", type=float, default=46)
    ap.add_argument("--alpha", type=float, default=0.9)
    return ap.parse_args()


def main():
    args = get_args()
    out_dir = os.path.dirname(args.out_prefix)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    mpl.rcParams.update({
        "font.size": args.fontsize,
        "axes.linewidth": 0.8,
        "axes.edgecolor": "#333333",
        "xtick.direction": "out",
        "ytick.direction": "out",
        "xtick.major.size": 3.0,
        "ytick.major.size": 3.0,
        "legend.frameon": False,
        "savefig.bbox": "tight",
        "savefig.transparent": False,
    })

    df = pd.read_csv(args.tsv, sep="\t")
    need_cols = {"UMAP_1", "UMAP_2", "pred_label"}
    missing = need_cols - set(df.columns)
    if missing:
        raise ValueError(f"Missing columns in {args.tsv}: {missing}")

    df["PredHost"] = df["pred_label"].fillna("Unknown")

    palette = {
        "Duck":         "#1f77b4",
        "Goose":        "#ff7f0e",
        "Muscovy duck": "#2ca02c",
        "Swan":         "#9467bd",
        "Unknown":      "#7f7f7f",
    }

    order = [c for c in ["Duck", "Goose", "Muscovy duck", "Swan", "Unknown"]
             if c in df["PredHost"].unique()]

    fig, ax = plt.subplots(figsize=(args.width, args.height), dpi=args.dpi)

    for host in order:
        sub = df[df["PredHost"] == host]
        ax.scatter(
            sub["UMAP_1"], sub["UMAP_2"],
            s=args.point_size,
            c=palette.get(host, "#7f7f7f"),
            edgecolor="white",
            linewidth=0.3,
            alpha=args.alpha,
            label=host,
        )

    ax.set_xlabel("UMAP-1")
    ax.set_ylabel("UMAP-2")
    ax.set_title("High confidence model-predicted host (kNN classifier)", pad=8)

    leg = ax.legend(
        title="Model-predicted host",
        title_fontsize=args.fontsize,
        fontsize=args.fontsize - 0.5,
        frameon=False,
        loc="center left",
        bbox_to_anchor=(1.02, 0.5),
        borderaxespad=0.0,
    )
    for lh in getattr(leg, "legend_handles", getattr(leg, "legendHandles", [])):
        try:
            lh.set_alpha(1.0)
            lh.set_linewidth(0.6)
            lh.set_edgecolor("white")
        except Exception:
            pass

    ax.grid(False)
    plt.tight_layout()

    for ext in (".png", ".pdf", ".svg"):
        fig.savefig(args.out_prefix + ext, dpi=args.dpi)
    plt.close(fig)

    print("[OK] Figure ->", args.out_prefix + ".png/.pdf/.svg")


if __name__ == "__main__":
    main()