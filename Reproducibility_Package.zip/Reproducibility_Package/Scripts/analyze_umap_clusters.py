#!/usr/bin/env python3
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import pairwise_distances
from sklearn.neighbors import NearestNeighbors
from scipy.spatial.distance import pdist, squareform

# =====================================================
# Load data
# =====================================================
emb_path = "results/esm/embeddings.npy"
labels_path = "results/esm/labels.tsv"
umap_path = "results/esm/umap_host.tsv"
outdir = "results/esm"

os.makedirs(outdir, exist_ok=True)
print(f"[INFO] Loading: {emb_path}")

emb = np.load(emb_path)
labels_df = pd.read_csv(labels_path, sep="\t")
umap_df = pd.read_csv(umap_path, sep="\t")

labels = labels_df["label"].values
unique_labels = sorted(set(labels))
print(f"[INFO] Found {len(unique_labels)} host groups: {unique_labels}")

# =====================================================
# Compute pairwise distances
# =====================================================
dist_matrix = pairwise_distances(emb, metric="euclidean")

# 簇内距离
intra = {}
for lab in unique_labels:
    idx = np.where(labels == lab)[0]
    if len(idx) < 2:
        intra[lab] = np.nan
    else:
        intra[lab] = np.mean(pdist(emb[idx], metric="euclidean"))

# 簇间距离矩阵
inter = pd.DataFrame(index=unique_labels, columns=unique_labels, dtype=float)
for i, lab_i in enumerate(unique_labels):
    for j, lab_j in enumerate(unique_labels):
        idx_i = np.where(labels == lab_i)[0]
        idx_j = np.where(labels == lab_j)[0]
        inter.loc[lab_i, lab_j] = np.mean(dist_matrix[np.ix_(idx_i, idx_j)])

# =====================================================
# 最近邻纯度
# =====================================================
def neighbor_purity(X, labels, k=5):
    nn = NearestNeighbors(n_neighbors=k + 1, metric="euclidean").fit(X)
    neigh_idx = nn.kneighbors(return_distance=False)
    correct = []
    for i in range(len(labels)):
        neigh_labs = labels[neigh_idx[i][1:]]
        same = np.sum(neigh_labs == labels[i]) / k
        correct.append(same)
    return np.mean(correct)

purity = neighbor_purity(emb, np.array(labels), k=5)
print(f"[OK] Nearest-neighbor purity = {purity:.3f}")

# =====================================================
# 汇总表
# =====================================================
summary = pd.DataFrame({
    "host": unique_labels,
    "intra_dist": [intra[h] for h in unique_labels],
    "n_samples": [np.sum(labels == h) for h in unique_labels]
})
summary.to_csv(f"{outdir}/cluster_stats.tsv", sep="\t", index=False)

inter.to_csv(f"{outdir}/cluster_distance_matrix.tsv", sep="\t")

# =====================================================
# 绘图：带上距离单位说明
# =====================================================
plt.figure(figsize=(6, 5))
ax = sns.heatmap(
    inter,
    cmap="viridis",
    annot=True,
    fmt=".2f"
)

plt.title("Inter-cluster distance (ESM VP1 embeddings)")

# 关键：给 colorbar 加 label
cbar = ax.collections[0].colorbar
cbar.set_label("Mean Euclidean distance in embedding space", rotation=270, labelpad=15)


plt.tight_layout()
plt.savefig(f"{outdir}/cluster_distance_heatmap.png", dpi=700)
plt.close()
# =====================================================
# 输出 summary
# =====================================================
with open(f"{outdir}/summary.txt", "w") as f:
    f.write(f"Nearest-neighbor purity: {purity:.3f}\n")
    f.write(f"Mean intra-cluster distance: {np.nanmean(list(intra.values())):.3f}\n")
    f.write(f"Mean inter-cluster distance: {np.nanmean(inter.values):.3f}\n")
    f.write(f"Separation index (inter/intra): {(np.nanmean(inter.values)/np.nanmean(list(intra.values()))):.3f}\n")

print("[DONE] Results written to:", outdir)