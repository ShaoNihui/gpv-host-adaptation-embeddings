#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Make per-residue Cα RMSD heatmap for VP1 loop 300–420
with a colorbar neatly placed just outside the main axis (right side).
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1.inset_locator import inset_axes


def main():
    # 1. 读入 PyMOL 生成的 TSV 文件
    in_tsv = "vp1_GPV_MDPV_loop_CA_RMSD.tsv"
    df = pd.read_csv(in_tsv, sep="\t")

    residues = df["residue"].values
    rmsd = df["CA_RMSD"].values

    # 2. 主图：单行 heatmap
    fig, ax = plt.subplots(figsize=(8, 2.3))

    im = ax.imshow(
        rmsd[np.newaxis, :],
        aspect="auto",
        cmap="viridis",
        extent=[residues[0] - 0.5, residues[-1] + 0.5, 0, 1],
        origin="lower",
    )

    ax.set_yticks([])
    ax.set_xlabel("VP1 residue (300–420)")
    ax.set_xlim(residues[0], residues[-1])
    xticks = np.arange(300, 421, 10)
    ax.set_xticks(xticks)

    # 3. 用 inset_axes 把 colorbar 嵌在轴右侧、与轴垂直居中对齐
    #    关键：loc 用 'lower left'，bbox_to_anchor 的 y=0.0，
    #    并用 ax.transAxes 作为坐标系。
    cax = inset_axes(
        ax,
        width="3%",            # colorbar 宽度
        height="100%",         # 与主轴等高
        loc="lower left",      # 以左下角为参考点
        bbox_to_anchor=(1.02, 0.0, 1, 1),  # 略微移出主轴 (x=1.02)
        bbox_transform=ax.transAxes,
        borderpad=0.0,
    )

    cbar = fig.colorbar(im, cax=cax)
    cbar.set_label("Cα RMSD (Å)", rotation=90, labelpad=8)

    plt.tight_layout()
    plt.savefig("Fig4E_loop_rmsd_heatmap.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()