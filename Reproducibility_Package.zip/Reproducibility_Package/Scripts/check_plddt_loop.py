import sys
import numpy as np

pdb_file = sys.argv[1]   # 用法：python check_plddt_loop.py GPV_model.pdb
loop_start, loop_end = 300, 420

loop_scores = []
other_scores = []

with open(pdb_file) as f:
    for line in f:
        if not line.startswith("ATOM"):
            continue
        res_id = int(line[22:26])
        plddt = float(line[60:66])   # B-factor 列

        if loop_start <= res_id <= loop_end:
            loop_scores.append(plddt)
        else:
            other_scores.append(plddt)

loop_scores = np.array(loop_scores)
other_scores = np.array(other_scores)

print(f"PDB: {pdb_file}")
print(f"Loop {loop_start}-{loop_end}: n={len(loop_scores)}, "
      f"mean={loop_scores.mean():.1f}, min={loop_scores.min():.1f}")
print(f"Non-loop:           n={len(other_scores)}, "
      f"mean={other_scores.mean():.1f}, min={other_scores.min():.1f}")