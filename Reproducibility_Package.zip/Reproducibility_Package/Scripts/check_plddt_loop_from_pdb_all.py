#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Check per-residue pLDDT (stored as B-factor) for VP1 loop 300–420
for all AlphaFold models 0–4 of GPV / MDPV / Transition.

Run this script from the Fold/ directory:
    python check_plddt_loop_from_pdb_all.py
"""

import os
import glob
from statistics import mean

# 要检查的残基范围
RES_START = 300
RES_END   = 420


def summarize_pdb(pdb_path, label):
    """
    从一个 PDB 里读取 Cα 原子的 B-factor（AlphaFold pLDDT），
    计算：
      - loop 300–420 的平均值 / 最小值
      - 全蛋白的平均值 / 最小值
    """
    loop_plddt = []
    all_plddt  = []

    with open(pdb_path) as f:
        for line in f:
            if not line.startswith("ATOM"):
                continue

            atom_name = line[12:16].strip()
            # 只看 Cα，更干净
            if atom_name != "CA":
                continue

            # 残基序号（列 23–26，注意 Python index 是 0-based）
            resseq_str = line[22:26].strip()
            if not resseq_str:
                continue
            res_id = int(resseq_str)

            # B-factor（列 61–66）
            try:
                bfactor = float(line[60:66])
            except ValueError:
                continue

            all_plddt.append(bfactor)
            if RES_START <= res_id <= RES_END:
                loop_plddt.append(bfactor)

    if not loop_plddt:
        raise ValueError(
            f"No loop residues {RES_START}-{RES_END} found in {pdb_path}"
        )

    return {
        "pdb": os.path.basename(pdb_path),
        "n_loop": len(loop_plddt),
        "loop_mean": mean(loop_plddt),
        "loop_min": min(loop_plddt),
        "global_mean": mean(all_plddt),
        "global_min": min(all_plddt),
    }


def run_for_folder(folder, pattern):
    print(f"\n=== {folder} ===")
    pdb_paths = sorted(glob.glob(os.path.join(folder, pattern)))
    if not pdb_paths:
        print(f"No PDBs matching pattern '{pattern}' in {folder}")
        return

    for pdb in pdb_paths:
        stats = summarize_pdb(pdb, folder)
        print(
            f"{stats['pdb']}: "
            f"loop n={stats['n_loop']}, "
            f"loop mean={stats['loop_mean']:.1f}, "
            f"loop min={stats['loop_min']:.1f}; "
            f"global mean={stats['global_mean']:.1f}, "
            f"global min={stats['global_min']:.1f}"
        )


if __name__ == "__main__":
    # 在 Fold/ 目录下调用
    run_for_folder("fold_gpv",        "fold_gpv_model_*.pdb")
    run_for_folder("fold_mdpv",       "fold_mdpv_model_*.pdb")
    run_for_folder("fold_transition", "fold_transition_model_*.pdb")