#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os, csv
from collections import Counter
import numpy as np
import matplotlib.pyplot as plt

GPV_FASTA  = "VP1_AA_region_300_420_GPV.aa.clean.fasta"
MDPV_FASTA = "VP1_AA_region_300_420_MDPV.aa.clean.fasta"
start_pos, end_pos = 300, 420
AA_ORDER = list("ARNDCEQGHILKMFPSTWYV")
DELTA_THRESHOLD = 0.20

def read_fasta_one_line_per_seq(fp):
    seqs = []
    with open(fp) as f:
        header = None
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith(">"):
                header = line[1:].split()[0]
            else:
                seqs.append((header, line.strip()))
    lens = {len(s) for _, s in seqs}
    if len(lens) != 1:
        raise ValueError(f"{fp} 中序列长度不一致: {lens}")
    return seqs

def count_freq(seqs, aa_order):
    nseq = len(seqs)
    L = len(seqs[0][1])
    mat = np.zeros((L, len(aa_order)), dtype=float)
    idx = {aa: i for i, aa in enumerate(aa_order)}
    for _, s in seqs:
        for i, ch in enumerate(s):
            if ch in idx:
                mat[i, idx[ch]] += 1
    if nseq > 0:
        mat /= float(nseq)
    return mat

def write_csv(path, mat, aa_order, start_pos):
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["pos"] + aa_order)
        for i in range(mat.shape[0]):
            w.writerow([start_pos + i] + list(np.round(mat[i, :], 6)))

gpv = read_fasta_one_line_per_seq(GPV_FASTA)
mdpv = read_fasta_one_line_per_seq(MDPV_FASTA)

L = len(gpv[0][1])
assert L == (end_pos - start_pos + 1), "长度与标注区段不一致，请检查。"

freq_gpv  = count_freq(gpv,  AA_ORDER)
freq_mdpv = count_freq(mdpv, AA_ORDER)
delta     = freq_mdpv - freq_gpv

write_csv("freq_gpv.csv",  freq_gpv,  AA_ORDER, start_pos)
write_csv("freq_mdpv.csv", freq_mdpv, AA_ORDER, start_pos)
write_csv("delta_freq.csv", delta,     AA_ORDER, start_pos)

max_abs = np.abs(delta).max(axis=1)
max_idx = np.abs(delta).argmax(axis=1)
max_aa  = [AA_ORDER[j] for j in max_idx]
with open("delta_max_by_pos.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["pos", "max_abs_delta", "aa", "delta(aa)"])
    for i in range(L):
        w.writerow([
            start_pos + i,
            np.round(max_abs[i], 6),
            max_aa[i],
            np.round(delta[i, max_idx[i]], 6)
        ])

with open("top_delta_positions.tsv", "w") as f:
    f.write("#pos\tabs_delta\tfavored_in\tresidue\n")
    for i in range(L):
        if max_abs[i] >= DELTA_THRESHOLD:
            pos = start_pos + i
            aa  = max_aa[i]
            raw = delta[i, max_idx[i]]
            favored = "MDPV" if raw > 0 else "GPV"
            f.write(f"{pos}\t{max_abs[i]:.3f}\t{favored}\t{aa}\n")

fig_w, fig_h = 10, 6
fig, ax = plt.subplots(figsize=(fig_w, fig_h))
im = ax.imshow(delta.T, aspect="auto", cmap="bwr", vmin=-0.5, vmax=0.5,
               interpolation="nearest")

ax.set_xlabel("Position (VP1 aa)")
ax.set_ylabel("Residue")
ax.set_yticks(range(len(AA_ORDER)))
ax.set_yticklabels(AA_ORDER)

step = 5 if L <= 150 else 10
xticks = list(range(0, L, step))
xticklabels = [str(start_pos + i) for i in xticks]
ax.set_xticks(xticks)
ax.set_xticklabels(xticklabels, rotation=0, fontsize=8)

cbar = plt.colorbar(im, ax=ax, pad=0.02)
cbar.set_label("Δf (MDPV − GPV)")

for i in range(L):
    if max_abs[i] >= DELTA_THRESHOLD:
        ax.plot(i, -0.6, marker="v", color="k", markersize=3, clip_on=False)

plt.tight_layout()
for ext in ("png", "pdf", "svg"):
    plt.savefig(f"delta_heatmap.{ext}", dpi=300, bbox_inches="tight")
plt.close()

print("✅ Done.")
print("  - freq_gpv.csv / freq_mdpv.csv / delta_freq.csv")
print("  - delta_max_by_pos.csv")
print(f"  - top_delta_positions.tsv （|Δf| ≥ {DELTA_THRESHOLD:.2f} 的位点清单）")
print("  - delta_heatmap.png/.pdf/.svg （红=MDPV富集，蓝=GPV富集）")
