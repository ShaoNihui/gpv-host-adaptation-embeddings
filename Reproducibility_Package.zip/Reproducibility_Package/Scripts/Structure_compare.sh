#!/usr/bin/env bash
#SBATCH --job-name=fig4A_structure_compare
#SBATCH --partition=pibu_el8
#SBATCH --cpus-per-task=8
#SBATCH --mem=16G
#SBATCH --time=04:00:00
#SBATCH --mail-user=nihui.shao@students.unibe.ch
#SBATCH --mail-type=BEGIN,END,FAIL
#SBATCH --output=/data/users/%u/GPV_AI_Project/Fig5_Structure_Electrostatics/logs/fig4A_%j.out
#SBATCH --error=/data/users/%u/GPV_AI_Project/Fig5_Structure_Electrostatics/logs/fig4A_%j.err

PYMOL="/data/users/nshao/conda_envs/pymol_env/bin/pymol"
PROJ="/data/users/nshao/GPV_AI_Project/Fig5_Structure_Electrostatics"
WORK="$PROJ/work"
OUT="$PROJ/outputs"
LOG="$PROJ/logs"

mkdir -p "$WORK" "$OUT" "$LOG"

cat > "$WORK/make_fig4A.pml" <<'PML'
reinitialize
set ray_opaque_background, off
set antialias, 2
set ray_shadows, off
set depth_cue, 0
bg_color white
set cartoon_transparency, 0.15
set two_sided_lighting, on
set surface_quality, 1
set label_font_id, 7
set label_size, 20

python
import os
BASE="/data/users/nshao/GPV_AI_Project/Fig5_Structure_Electrostatics"
INP = os.path.join(BASE, "inputs")
WRK = os.path.join(BASE, "work")
OUT = os.path.join(BASE, "outputs")
os.makedirs(WRK, exist_ok=True)
os.makedirs(OUT, exist_ok=True)
files = {
  "GPV_cif":  os.path.join(INP, "fold_gpv_model_0.cif"),
  "MDPV_cif": os.path.join(INP, "fold_mdpv_model_0.cif"),
  "GPV_pdb":  os.path.join(WRK, "GPV_model.pdb"),
  "MDPV_pdb": os.path.join(WRK, "MDPV_model.pdb"),
}
python end

python
def load_clean(cif_path, obj_name, save_pdb):
    cmd.load(cif_path, obj_name)
    cmd.remove(f"{obj_name} and (resn HOH or hetatm)")
    cmd.save(save_pdb, obj_name)

load_clean(files["GPV_cif"],  "GPV",  files["GPV_pdb"])
load_clean(files["MDPV_cif"], "MDPV", files["MDPV_pdb"])
python end

hide everything
show cartoon, GPV or MDPV

set_color gpv_col,  [0.00, 0.45, 0.70]
set_color mdpv_col, [0.90, 0.60, 0.00]
color gpv_col, GPV
color mdpv_col, MDPV

align MDPV, GPV

select GPV_loop,  GPV  and resi 300-420
select MDPV_loop, MDPV and resi 300-420

set cartoon_transparency, 0.5, GPV or MDPV
set cartoon_transparency, 0.0, GPV_loop or MDPV_loop
set cartoon_width, 0.3

set_color gpv_loop_col,  [0.00, 0.62, 0.45]
set_color mdpv_loop_col, [0.84, 0.15, 0.16]
color gpv_loop_col,  GPV_loop
color mdpv_loop_col, MDPV_loop

pseudoatom label_GPV,  GPV  and name CA and resi 330
pseudoatom label_MDPV, MDPV and name CA and resi 330
label label_GPV,  "GPV"
label label_MDPV, "MDPV"

set label_color, gpv_col, label_GPV
set label_color, mdpv_col, label_MDPV
set label_outline_color, white

translate [-45, 45, 0], label_GPV, camera=1
translate [-45, 35, 0], label_MDPV, camera=1

orient GPV
turn y, 20
turn x, -10
zoom all, 1.0

ray 2400, 1800
png /data/users/nshao/GPV_AI_Project/Fig5_Structure_Electrostatics/outputs/Fig4A_VP1_GPV_MDPV_superposition.png, dpi=600
PML

"$PYMOL" -cq "$WORK/make_fig4A.pml"